# NEXO - Master Product & Engineering Specification

Versão consolidada 1.0

> Documento-base para Produto, Design, Engenharia e Codex. Em caso de conflito, Constitution e segurança prevalecem.

## 1. Visão e posicionamento

### Visão

O NEXO é uma plataforma SaaS omnichannel, multiempresa e orientada por inteligência artificial para atendimento, vendas, relacionamento, automações e operação empresarial. O nome é provisório e poderá ser alterado sem impacto na arquitetura.

### Problema

Empresas atendem por canais desconectados, perdem contexto, repetem tarefas, demoram para responder e possuem pouca visibilidade sobre qualidade, custos e conversão.

### Proposta de valor

Centralizar conversas, CRM, agentes de IA, voz, automações, conhecimento, integrações e analytics em uma única plataforma segura e escalável.

### Princípio de produto

O NEXO não deve ser tratado apenas como chatbot. Ele deve funcionar como um sistema operacional de atendimento e relacionamento com clientes.

## 2. Escopo do produto

### MVP

Autenticação, organizações, usuários, equipes, papéis e permissões; inbox omnichannel; WhatsApp e Instagram; contatos; histórico; agentes de IA para texto; transcrição e resposta por áudio; base de conhecimento inicial; dashboard; logs; auditoria; limites de uso e configurações.

### Pós-MVP

CRM avançado, pipeline, editor visual de automações, analytics 360, billing, marketplace, APIs públicas, white-label, SSO, SCIM e recursos enterprise.

### Fora do escopo inicial

Telefonia SIP, marketplace avançado, dezenas de integrações de nicho, white-label completo e recursos enterprise não essenciais à validação do núcleo.

## 3. Personas e permissões

### Perfis

Owner, Administrador, Supervisor, Atendente, Analista, Desenvolvedor e Financeiro.

### Autorização

RBAC define papéis e permissões gerais. ABAC aplica restrições por organização, equipe, canal, departamento, contato, conversa e recurso.

### Isolamento

Todos os dados devem estar associados à organização e nunca podem vazar entre tenants.

## 4. Experiência e módulos

### Módulos

Dashboard, Inbox Omnichannel, CRM, Pipeline, AI Command Center, AI Copilot, Live Activity, Organization Map, AI Knowledge Center, Flow Builder, Automation Monitor, Analytics, Integrações, Equipes, Segurança, Billing, Marketplace, API e Configurações.

### UX

Desktop first, responsivo, dark/light mode, busca global, command palette, atalhos, estados vazios, loading, erro, sucesso, permissão e microinterações consistentes.

### IA transversal

A IA deve sugerir resumos, próximas ações, riscos, oportunidades, respostas, automações e insights em todas as áreas relevantes.

## 5. Arquitetura técnica

### Stack

Frontend: Next.js, React, TypeScript, Tailwind, shadcn/ui, TanStack Query, Zustand, React Hook Form e Zod. Backend: NestJS, PostgreSQL, Prisma, Redis, BullMQ, WebSockets, REST, webhooks e OpenAPI. Infra: Docker, GitHub Actions, armazenamento S3 compatível e observabilidade.

### Monorepo

apps/web, apps/api, apps/worker, apps/webhook-gateway; packages/database, auth, ai, channels, voice, workflows, ui, config, observability e shared.

### Princípios

Arquitetura modular, API-first, provider-agnostic, componentes desacoplados, escalabilidade horizontal, observabilidade e segurança por padrão.

## 6. Fluxo de mensagens

### Texto

Canal -> webhook -> validação e idempotência -> normalização -> identificação da organização e contato -> persistência -> fila -> classificação -> memória -> conhecimento/ferramentas -> geração -> supervisão -> envio -> CRM -> analytics -> auditoria.

### Áudio

Canal -> download seguro -> armazenamento temporário -> conversão -> speech-to-text -> IA -> text-to-speech quando necessário -> upload -> envio -> transcrição e métricas registradas.

### Humano

A conversa pode operar em modo automático, assistido, híbrido ou humano. Toda transferência deve incluir resumo, intenção, sentimento, ações executadas, fontes consultadas e resposta sugerida.

## 7. Arquitetura de IA

### Agentes

Reception, Classifier, Memory, Knowledge, Workflow, CRM, Voice, Supervisor e Analytics.

### Memória

Curto prazo para conversa atual; médio prazo para histórico do cliente; longo prazo para preferências e fatos persistentes; memória organizacional para documentos, políticas e conhecimento.

### RAG

Fontes são processadas, segmentadas, indexadas e recuperadas com metadados, escopo por organização, agente e departamento, versionamento, exclusão e rastreabilidade.

### Ferramentas

CRM, calendário, ERP, pagamentos, HTTP, banco de dados, workflows, knowledge base, analytics e notificações.

### Supervisor

Valida confiança, segurança, tom, políticas, informações sensíveis, necessidade de esclarecimento e transferência humana.

### Observabilidade

Registrar modelo, versão de prompt, tokens, custo, latência, ferramentas, fontes, retries, erros, confiança e resultado.

## 8. Arquitetura de voz

### Capacidades

Receber áudio, detectar idioma, transcrever, resumir, responder em texto ou áudio, selecionar perfil de voz e armazenar transcrição.

### Perfis

Voz, idioma, sotaque, velocidade, tom, formalidade e política de resposta.

### Segurança

Arquivos privados, URLs temporárias, criptografia, retenção configurável e acesso por tenant.

### Fallback

Retry controlado, troca de provedor, solicitação de novo áudio ou transferência para humano.

## 9. Workflow Engine

### Modelo

Editor drag-and-drop com gatilhos, condições, transformações, ações, delays, loops, subfluxos e tratamento de erros.

### Gatilhos

Mensagem recebida, contato criado, mudança de estágio, webhook, agenda, pagamento, evento personalizado e execução manual.

### Ações

Enviar texto/áudio, consultar IA, consultar CRM, HTTP, atualizar dados, criar atividade, enviar e-mail, cobrar, chamar fluxo, executar código seguro e encaminhar para humano.

### Execução

Cada execução possui contexto, variáveis, logs, duração, custos, nós executados, erros, retries e resultado.

### Resiliência

Retries configuráveis, fallback, dead-letter queue, idempotência, versionamento, rascunho, publicação e rollback.

## 10. Banco de dados

### Domínios

Core, Inbox, CRM, AI, Automation, Voice, Analytics e Platform.

### Entidades principais

Organization, Subscription, Plan, User, Role, Permission, Membership, Team, Channel, Contact, Company, Conversation, Message, Attachment, Tag, Note, Assignment, Pipeline, Stage, Opportunity, Activity, Agent, Prompt, KnowledgeSource, KnowledgeChunk, Memory, Tool, Workflow, WorkflowNode, WorkflowExecution, Webhook, Audio, Transcript, VoiceProfile, Metric, Event, ApiKey, AuditLog, Notification e FeatureFlag.

### Convenções

UUID, timestamps, organization_id quando aplicável, soft delete seletivo, created_by/updated_by, versionamento otimista e metadados JSON somente quando justificado.

### Integridade

Foreign keys, constraints, índices por tenant/status/timestamp/canal/contato/conversa e migrations imutáveis após publicação.

## 11. APIs e integrações

### Padrões

REST para negócio, WebSockets para tempo real, webhooks para eventos externos, OpenAPI obrigatório, versionamento /v1 e idempotência em operações críticas.

### Grupos

Auth, Organizations, Users, Teams, Roles, Inbox, CRM, AI, Voice, Workflows, Analytics, Billing, API Keys e Webhooks.

### Canais

Priorizar APIs oficiais da Meta para WhatsApp Business e Instagram Messaging, com validação de assinatura, idempotência, retries e histórico de entrega.

### Segredos

Credenciais criptografadas, nunca expostas no frontend ou repositório.

## 12. Segurança e LGPD

### Princípios

Security by Design, Least Privilege, Zero Trust, Defense in Depth, Privacy by Design e isolamento multi-tenant.

### Autenticação

Access token curto, refresh token rotativo, sessões revogáveis, MFA/2FA, passkeys planejadas e proteção contra brute force.

### APIs

Rate limiting, validação de entrada, CORS restrito, proteção contra replay, assinatura de webhooks, API keys com escopo e rotação.

### Dados

TLS, criptografia de dados sensíveis, retenção, exportação, anonimização, exclusão, consentimento e trilha de auditoria.

### Recuperação

Backups, testes de restauração, RPO/RTO documentados e plano de desastre.

## 13. Testes e qualidade

### Estratégia

Testes unitários, integração, E2E, performance, carga, segurança e avaliações de IA.

### Cobertura

Regras de negócio >=90%, serviços críticos >=95% como meta inicial; fluxos críticos do MVP com E2E obrigatório.

### E2E críticos

Cadastro/login, multiempresa, conexão de canais, recebimento e envio de texto, áudio, transferência humana, CRM, automação, conhecimento, upload privado e permissões.

### IA

Avaliar qualidade, factualidade, alucinação, segurança, custo, latência, ferramentas e regressões de prompt.

### Gate

Lint, format, typecheck, testes, build, security scan, migrations e CI verde.

## 14. DevOps e operação

### Ambientes

Local, development, staging, production e sandbox de integrações.

### Pipeline

PR -> lint -> typecheck -> unit -> integration -> E2E -> build -> security scan -> staging -> aprovação -> produção.

### Observabilidade

Logs estruturados, métricas, tracing, health checks, alertas e dashboards para API, filas, banco, canais, IA e voz.

### Deploy

Rollback definido, migrações seguras, monitoramento pós-deploy e changelog.

## 15. Constitution

### Regras

TypeScript strict; sem segredos no código; sem duplicação de lógica; contratos claros; migrations versionadas; documentação e testes obrigatórios; segurança, acessibilidade e observabilidade por padrão.

### Escopo

O Codex não deve alterar módulos fora da fase sem justificativa. Breaking changes exigem documentação e estratégia de migração.

### Definition of Done

Requisitos atendidos, testes aprovados, documentação atualizada, CI verde, segurança validada, sem regressões conhecidas e relatório final.

## 16. Plano de implementação

### Fase 0

Bootstrap do repositório, monorepo, ferramentas, CI, ambientes e documentação.

### Fase 1

Fundação SaaS: autenticação, organizações, usuários, equipes, RBAC/ABAC e auditoria.

### Fase 2

Design System, shell da aplicação e navegação.

### Fase 3

Inbox, contatos, conversas, mensagens, anexos, filas e tempo real.

### Fase 4

WhatsApp e Instagram com webhooks, normalização, envio e retries.

### Fase 5

IA textual, agentes, memória, RAG, ferramentas, supervisor e custos.

### Fase 6

Voz: STT, TTS, perfis, armazenamento e métricas.

### Fase 7

CRM e pipeline.

### Fase 8

Workflow Engine e monitor de automações.

### Fase 9

Analytics, billing, marketplace e APIs públicas.

### Fase 10

Hardening, performance, segurança, documentação, staging e produção.

## 17. Procedimento obrigatório para o Codex

### Antes

Ler README, Constitution, PRD, arquitetura e especificação da fase. Inspecionar o repositório e registrar riscos.

### Durante

Implementar apenas o escopo, criar migrations, testes, logs e documentação. Não usar mocks como substituto de integração real em produção.

### Depois

Executar todos os gates, corrigir falhas, revisar diff, atualizar changelog, produzir relatório e criar commit convencional.

### Relatório

Objetivos, alterações, arquivos, migrations, testes, riscos, pendências, evidências e próximo passo.

## 18. Aprovação e controle de mudanças

Toda mudança de escopo, arquitetura, segurança, banco, contratos públicos ou Definition of Done deve ser registrada em ADR ou changelog antes da implementação.