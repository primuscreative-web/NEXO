# Pacote NEXO para Codex

Este pacote consolida a documentação atual do projeto NEXO.

## Ordem de leitura obrigatória
1. `CODEX_START_PROMPT.md`
2. `NEXO_Master_Consolidated_v1.0.md`
3. `docs_original/NEXO_Constitution_v1.0.docx`
4. Demais documentos originais conforme a fase

## Regra
Não iniciar implementação ampla em uma única execução. Trabalhar fase por fase, com plano, testes, documentação, CI verde e relatório de encerramento.

## Conteúdo
- Documento mestre consolidado em DOCX e Markdown
- Prompt inicial para o Codex
- Manifesto dos arquivos
- Cópias dos documentos originais
